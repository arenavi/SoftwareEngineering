'use strict';

var App = angular.module('logsApp',[]);