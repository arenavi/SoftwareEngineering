package edu.ncsu.csc.itrust2.models.enums;

/**
 * Enum of all of the types of diagnoses that are recognized by the system.
 *
 * @author Saahil Bhutwala
 *
 */
public enum DiagnosesType {

    /**
     * Cataracts
     */
    Cataracts ( 1 ),
    /**
     * Age-related macular degeneration
     */
    Macular_Degeneration ( 2 ),
    /**
     * Amblyopia
     */
    Amblyopia ( 3 ),
    /**
     * Glaucoma
     */
    Glaucoma ( 4 );

    private int code;

    private DiagnosesType ( final int code ) {
        this.code = code;
    }

    /**
     * Returning code
     * 
     * @return code
     */
    public int getCode () {
        return this.code;
    }
}
