package edu.ncsu.csc.itrust2.models.enums;

/**
 * Enum defining the types of ophthalmological surgery
 * 
 * @author Wil Elias
 *
 */
public enum SurgeryType {
    /**
     * Cataract
     */
    CATARACT,
    /**
     * Laser
     */
    LASER,
    /**
     * Refractive
     */
    REFRACTIVE

}
