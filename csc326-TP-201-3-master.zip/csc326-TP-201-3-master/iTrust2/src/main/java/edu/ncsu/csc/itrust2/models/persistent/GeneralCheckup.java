package edu.ncsu.csc.itrust2.models.persistent;

import java.text.ParseException;
import java.util.List;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

import edu.ncsu.csc.itrust2.forms.hcp.OfficeVisitForm;

/**
 * Class acting as the normal office visit that was supported prior to the
 * addition of UC20 & 21
 *
 * @author Wil Elias
 */
@Entity
@DiscriminatorValue ( "1" )
public class GeneralCheckup extends OfficeVisit {
    /**
     * Constructor to be used by hibernate/Thymeleaf
     */
    public GeneralCheckup () {
    }

    /**
     * Accepts an OfficeVisitForm and uses the information in that to create an
     * GeneralCheckup object
     *
     * @param ovf
     *            - the OfficeVisitForm with desired information
     * @throws ParseException
     *             - if the information is in the wrong format
     * @throws NumberFormatException
     *             - the the values are of an unacceptable value
     */
    public GeneralCheckup ( final OfficeVisitForm ovf ) throws ParseException, NumberFormatException {
        super( ovf );
    }

    /**
     * Getting list of general checkups
     *
     * @return list of general checkups
     */
    @SuppressWarnings ( "unchecked" )
    public static List<GeneralCheckup> getGeneralCheckups () {
        final List<GeneralCheckup> visits = (List<GeneralCheckup>) getAll( GeneralCheckup.class );
        visits.sort( ( x1, x2 ) -> x1.getDate().compareTo( x2.getDate() ) );
        return visits;
    }
}
