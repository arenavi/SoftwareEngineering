package edu.ncsu.csc.itrust2.models.persistent;

import java.text.ParseException;
import java.util.List;

import javax.persistence.DiscriminatorValue;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.validation.constraints.NotNull;

import edu.ncsu.csc.itrust2.forms.hcp.OfficeVisitForm;
import edu.ncsu.csc.itrust2.models.enums.AppointmentType;
import edu.ncsu.csc.itrust2.models.enums.DiagnosesType;
import edu.ncsu.csc.itrust2.models.enums.Role;
import edu.ncsu.csc.itrust2.models.enums.SurgeryType;

/**
 * Extends OfficeVisit to hold the rest of the information for UC20/UC21.
 * Validates information. Is persistent.
 *
 * @author Wil Elias
 *
 */
@Entity
@DiscriminatorValue ( "2" )
public class OptometryVisit extends OfficeVisit {

    /**
     * Used by Hibernate/Thymeleaf
     */
    public OptometryVisit () {
    }

    /**
     * Accepts an OfficeVisitForm as an argument and uses its fields to build an
     * OptometryVisit object
     *
     * @param ovf
     *            - the OfficeVisitForm with the inputed data
     * @throws ParseException
     *             - if the data is in an unreadable format
     * @throws NumberFormatException
     *             - if the data is of an unacceptable value
     */
    public OptometryVisit ( final OfficeVisitForm ovf ) throws ParseException, NumberFormatException {
        super( ovf );
        setHcp( User.getByNameAndRole( ovf.getHcp(), Role.ROLE_OPTOMETRISTHCP ) );
        if ( getHcp() == null ) {
            setHcp( User.getByNameAndRole( ovf.getHcp(), Role.ROLE_OPHTHALMOLOGISTHCP ) );
        }
        if ( getHcp() == null ) {
            throw new IllegalArgumentException( "Not a valid hcp" );
        }
        if ( getHcp().getRole() != Role.ROLE_OPHTHALMOLOGISTHCP && getHcp().getRole() != Role.ROLE_OPTOMETRISTHCP ) {
            throw new IllegalArgumentException( "Cannot have an optometry visit with a regular HCP" );
        }
        try {
            if ( ovf.getType().equals( AppointmentType.GENERAL_OPHTHALMOLOGY.toString() )
                    && ovf.getDiagnosesType().size() != 0 ) {
                setDiagnosesType( ovf.getDiagnosesType() );
            }
            else if ( ovf.getType().equals( AppointmentType.OPHTHALMOLOGY_SURGERY.toString() )
                    && !ovf.getSurgeryType().equals( null )
                    && this.getHcp().getRole() == Role.ROLE_OPHTHALMOLOGISTHCP ) {
                setSurgeryType( SurgeryType.valueOf( ovf.getSurgeryType() ) );
            }
            else {
                throw new IllegalArgumentException( "Must have either a diagnosis or a surgery type" );
            }
        }
        catch ( final NullPointerException e ) {
            throw new IllegalArgumentException( "Must have either a diagnosis or a surgery type" + e.getMessage() );
        }

        setVisualRight( Double.parseDouble( ovf.getVisualRight() ) );
        setVisualLeft( Double.parseDouble( ovf.getVisualLeft() ) );
        setSphereRight( Double.parseDouble( ovf.getSphereRight() ) );
        setSphereLeft( Double.parseDouble( ovf.getSphereLeft() ) );
        try {
            if ( !ovf.getCylinderRight().equals( "" ) ) {
                setCylinderRight( Double.parseDouble( ovf.getCylinderRight() ) );
                setAxisRight( Integer.parseInt( ovf.getAxisRight() ) );
            }
            if ( !ovf.getCylinderLeft().equals( "" ) ) {
                setCylinderLeft( Double.parseDouble( ovf.getCylinderLeft() ) );
                setAxisLeft( Integer.parseInt( ovf.getAxisLeft() ) );
            }
        }
        catch ( final NullPointerException e ) {
            // throw new IllegalArgumentException( "Did not fill in
            // corresponding axis to cylinder" );
        }
    }

    /**
     * The diagnoses associated with the OptometryVisit: assuming its not a
     * surgery
     */
    @ElementCollection ( fetch = FetchType.EAGER )
    private transient List<DiagnosesType> diagnosesType;

    /**
     * Setting diagnosis type
     *
     * @param dt
     *            Diagnosis type
     */
    public void setDiagnosesType ( final List<DiagnosesType> dt ) {
        diagnosesType = dt;
    }

    /**
     * Diagnosis type list return
     *
     * @return list of diagnosis
     */
    public List<DiagnosesType> getDiagnosesType () {
        return this.diagnosesType;
    }

    /**
     * The type of surgery associated with this OptometryVisit: assuming its not
     * a checkup
     */
    private SurgeryType surgeryType;

    /**
     * Setting surgery type
     *
     * @param st
     *            surgery type
     */
    public void setSurgeryType ( final SurgeryType st ) {
        surgeryType = st;
    }

    /**
     * Get surgery type
     *
     * @return surgery type
     */
    public SurgeryType getSurgeryType () {
        return this.surgeryType;
    }

    /**
     * The visual acuity of their right eye
     */
    @NotNull
    private double visualRight;

    /**
     * Set visual right
     *
     * @param vr
     *            visualRight
     */
    public void setVisualRight ( final double vr ) {
        this.visualRight = vr;
    }

    /**
     * Get visual right
     *
     * @return visual right
     */
    public double getVisualRight () {
        return this.visualRight;
    }

    /**
     * The visual acuity of their left eye
     */
    @NotNull
    private double visualLeft;

    /**
     * Set visual left
     *
     * @param vl
     *            visual Left
     */
    public void setVisualLeft ( final double vl ) {
        this.visualLeft = vl;
    }

    /**
     * Get visual left
     *
     * @return visual left
     */
    public double getVisualLeft () {
        return this.visualLeft;
    }

    /**
     * The sphere radius of their right eye
     */
    @NotNull
    private double sphereRight;

    /**
     * Set sphere right
     *
     * @param sr
     *            sphere right
     */
    public void setSphereRight ( final double sr ) {
        this.sphereRight = sr;
    }

    /**
     * Get sphere right
     *
     * @return sphereRight
     */
    public double getSphereRight () {
        return this.sphereRight;
    }

    /**
     * The sphere radius of their left eye
     */
    @NotNull
    private double sphereLeft;

    /**
     * Set sphere left
     *
     * @param sl
     *            sphereLeft
     */
    public void setSphereLeft ( final double sl ) {
        this.sphereLeft = sl;
    }

    /**
     * Get sphere Left
     *
     * @return sphereLEft
     */
    public double getSphereLeft () {
        return this.sphereLeft;
    }

    /**
     * OPTIONAL: The radius of the cylinder in their right eye
     */
    private double cylinderRight;

    /**
     * Set cylinderRight
     *
     * @param cr
     *            cylinderRight
     */
    public void setCylinderRight ( final double cr ) {
        this.cylinderRight = cr;
    }

    /**
     * Get cylinderRight
     *
     * @return cylinderRight
     */
    public double getCylinderRight () {
        return this.cylinderRight;
    }

    /**
     * OPTIONAL: The radius of the cylinder in their left eye
     */
    private double cylinderLeft;

    /**
     * Set cylinderLeft
     *
     * @param cl
     *            cylinderLeft
     */
    public void setCylinderLeft ( final double cl ) {
        this.cylinderLeft = cl;
    }

    /**
     * Get cylinderLeft
     *
     * @return cylinderLEft
     */
    public double getCylinderLeft () {
        return this.cylinderLeft;
    }

    /**
     * OPTIONAL: IF CYLINDER RIGHT IS PRESENT THIS MUST BE PRESENT: The axis of
     * the right eye cylinder
     */
    private int axisRight;

    /**
     * Set axis Right
     *
     * @param ar
     *            axisRight
     */
    public void setAxisRight ( final int ar ) {
        this.axisRight = ar;
    }

    /**
     * Set axis Right
     *
     * @return axisRight
     */
    public int getAxisRight () {
        return this.axisRight;
    }

    /**
     * OPTIONAL: IF CYLINDER LEFT IS PRESENT THIS MUST BE PRESENT: The axis of
     * the left eye cylinder
     */
    private int axisLeft;

    /**
     * Set axis left
     *
     * @param al
     *            axisRight
     */
    public void setAxisLeft ( final int al ) {
        this.axisLeft = al;
    }

    /**
     *
     * Get axis left
     *
     * @return axisLeft
     */
    public int getAxisLeft () {
        return this.axisLeft;
    }

    /**
     * Return optometry visits
     *
     * @return list of optometry visits
     */
    @SuppressWarnings ( "unchecked" )
    public static List<OptometryVisit> getOptometryVisits () {
        final List<OptometryVisit> visits = (List<OptometryVisit>) getAll( OptometryVisit.class );
        visits.sort( ( x1, x2 ) -> x1.getDate().compareTo( x2.getDate() ) );
        return visits;
    }
}
