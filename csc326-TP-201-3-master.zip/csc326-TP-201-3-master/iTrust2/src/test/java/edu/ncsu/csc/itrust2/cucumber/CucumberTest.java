package edu.ncsu.csc.itrust2.cucumber;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import com.paulhammant.ngwebdriver.NgWebDriver;

import io.github.bonigarcia.wdm.ChromeDriverManager;

/**
 * Set up for cucumber
 *
 * @author Rohan
 *
 */
public abstract class CucumberTest {

    static {
        ChromeDriverManager.getInstance().setup();
    }

    final static private String   BASE_URL = "http://localhost:8080/iTrust2/";

    final static private String   OS       = System.getProperty( "os.name" );
    /**
     * Driver for chrome
     */
    static protected ChromeDriver driver;

    /**
     * Trying to log out
     */
    protected void attemptLogout () {
        try {
            driver.get( BASE_URL );
            driver.findElement( By.id( "logout" ) ).click();
        }
        catch ( final Exception e ) {
            // do nothing
        }
    }

    /**
     * Set up for selenium tests
     */
    static public void setup () {

        final ChromeOptions options = new ChromeOptions();
        options.addArguments( "headless" );
        options.addArguments( "window-size=1200x600" );
        options.addArguments( "blink-settings=imagesEnabled=false" );

        if ( linuxOS() ) {
            options.setBinary( "/usr/bin/google-chrome" );
        }
        else if ( windowsOS() ) {
            options.setBinary( "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe" );
        }
        else if ( macOS() ) {
            options.setBinary( "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" );
        }

        driver = new ChromeDriver( options );

    }

    /**
     * Check OS
     *
     * @return true if MAC
     */
    static private boolean macOS () {
        return OS.contains( "Mac OS X" );
    }

    /**
     * Check OS
     *
     * @return true if Linux
     */
    static private boolean linuxOS () {
        return OS.contains( "Linux" );
    }

    /**
     * Check OS
     *
     * @return true if Windows
     */
    static private boolean windowsOS () {
        return OS.contains( "Windows" );
    }

    /**
     * Shutting down test
     */
    static public void tearDown () {
        driver.close();
        driver.quit();

        if ( windowsOS() ) {
            windowsKill();
        }
        else if ( linuxOS() || macOS() ) {
            unixKill();
        }

    }

    /**
     * Waiting for angular to finish
     */
    protected void waitForAngular () {
        new NgWebDriver( driver ).waitForAngularRequestsToFinish();
    }

    static private void windowsKill () {
        try {
            Runtime.getRuntime().exec( "taskkill /f /im chrome.exe" );
            Runtime.getRuntime().exec( "taskkill /f /im chromedriver.exe" );
        }
        catch ( final Exception e ) {
            // do nothing;
        }
    }

    static private void unixKill () {
        try {
            Runtime.getRuntime().exec( "pkill -f chromium-browser" );
            Runtime.getRuntime().exec( "pkill -f chrome" );
            Runtime.getRuntime().exec( "pkill -f chromedriver" );
        }
        catch ( final Exception e ) {
            // do nothing
        }

    }
}
