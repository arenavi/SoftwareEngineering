package edu.ncsu.csc.itrust2.cucumber;

import static org.junit.Assert.assertTrue;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import edu.ncsu.csc.itrust2.models.enums.AppointmentType;
import edu.ncsu.csc.itrust2.models.enums.Role;
import edu.ncsu.csc.itrust2.models.enums.Status;
import edu.ncsu.csc.itrust2.models.persistent.AppointmentRequest;
import edu.ncsu.csc.itrust2.models.persistent.DomainObject;
import edu.ncsu.csc.itrust2.models.persistent.User;

/**
 * Cucumber Step Defs features for Ophthalmologist appointments.
 *
 * @author Amiya Renavikar
 *
 */
public class OphthalmologistAppointmentsStepDefs extends CucumberTest {

    private final String baseUrl = "http://localhost:8080/iTrust2";

    @Given ( "There is a sample Ophthalmology HCP and sample Patient in the database" )
    public void startingOpthUsers () {
        attemptLogout();

        final User ophthalhcp = new User( "opht1", "$2a$10$EblZqNptyYvcLm/VwDCVAuBjzZOI7khzdyGPBr08PpIi0na624b8.",
                Role.ROLE_OPHTHALMOLOGISTHCP, 1 );
        ophthalhcp.save();

        final User patient = new User( "patient", "$2a$10$EblZqNptyYvcLm/VwDCVAuBjzZOI7khzdyGPBr08PpIi0na624b8.",
                Role.ROLE_PATIENT, 1 );
        patient.save();
    }

    /*
     * @When ( "I log in as patient" ) public void loginPatient () { driver.get(
     * baseUrl ); final WebElement username = driver.findElement( By.name(
     * "username" ) ); username.clear(); username.sendKeys( "patient" ); final
     * WebElement password = driver.findElement( By.name( "password" ) );
     * password.clear(); password.sendKeys( "123456" ); final WebElement submit
     * = driver.findElement( By.className( "btn" ) ); submit.click(); }
     */

    @When ( "I navigate to my Request Appointment page" )
    public void requestPage () {
        ( (JavascriptExecutor) driver ).executeScript( "document.getElementById('requestappointment').click();" );
    }

    @When ( "I fill in values in the Ophthalmology Appointment Request Fields" )
    public void fillFields () {
        waitForAngular();
        final Select ophthalhcp = new Select( driver.findElement( By.id( "hcp" ) ) );
        ophthalhcp.selectByVisibleText( "opht1" );

        final Select type = new Select( driver.findElement( By.name( "type" ) ) );
        type.selectByVisibleText( "GENERAL_OPHTHALMOLOGY" );

        final WebElement date = driver.findElement( By.id( "date" ) );
        date.clear();
        final SimpleDateFormat sdf = new SimpleDateFormat( "MM/dd/yyyy", Locale.ENGLISH );
        final Long value = Calendar.getInstance().getTimeInMillis()
                + 1000 * 60 * 60 * 24 * 14; /* Two weeks */
        final Calendar future = Calendar.getInstance();
        future.setTimeInMillis( value );
        date.sendKeys( sdf.format( future.getTime() ) );
        final WebElement time = driver.findElement( By.id( "time" ) );
        time.clear();
        time.sendKeys( "11:59 PM" );
        final WebElement comments = driver.findElement( By.id( "comments" ) );
        comments.clear();
        comments.sendKeys( "Test appointment please ignore" );
        driver.findElement( By.name( "submit" ) ).click();

        assertTrue( driver.getPageSource().contains( "Your appointment has been requested successfully" ) );

    }

    /*
     * @Then ( "The Ophthalmology appointment is requested successfully" )
     * public void requestedSuccessfully () { waitForAngular(); assertTrue(
     * driver.getPageSource().contains(
     * "Your appointment has been requested successfully" ) ); waitForAngular();
     * }
     */

    /*
     * @And ( "The Ophthalmology appointment can be found in the list" ) public
     * void findAppointment () { waitForAngular(); ( (JavascriptExecutor) driver
     * ).executeScript( "document.getElementById('requestappointment').click();"
     * ); final SimpleDateFormat sdf = new SimpleDateFormat( "yyyy",
     * Locale.ENGLISH ); final Long value =
     * Calendar.getInstance().getTimeInMillis() + 1000 * 60 * 60 * 24 * 14;
     * final Calendar future = Calendar.getInstance(); future.setTimeInMillis(
     * value ); final String dateString = sdf.format( future.getTime() );
     * waitForAngular(); assertTrue( driver.getPageSource().contains( dateString
     * ) ); }
     */

    @Given ( "An Ophthalmology appointment request exists" )
    public void createAppointmentRequest () {
        attemptLogout();

        DomainObject.deleteAll( AppointmentRequest.class );
        final AppointmentRequest ar = new AppointmentRequest();
        ar.setComments( "Test request" );
        ar.setPatient( User.getByNameAndRole( "patient", Role.ROLE_PATIENT ) );
        ar.setHcp( User.getByNameAndRole( "opht1", Role.ROLE_OPHTHALMOLOGISTHCP ) );
        final Calendar time = Calendar.getInstance();
        time.setTimeInMillis( Calendar.getInstance().getTimeInMillis() + 1000 * 60 * 60 * 24 * 14 );
        ar.setDate( time );
        ar.setStatus( Status.PENDING );
        ar.setType( AppointmentType.GENERAL_OPHTHALMOLOGY );
        ar.save();

    }

    @And ( "I navigate to the View Ophthalmology Requests page" )
    public void viewRequests () {
        // ( (JavascriptExecutor) driver ).executeScript(
        // "document.getElementById('viewrequests').click();" );
        driver.get( "http://localhost:8080/iTrust2/ophthalmologist/appointmentRequests" );

    }

    @And ( "I approve the Ophthalmology Appointment Request" )
    public void approveRequest () {
        waitForAngular();
        driver.findElement( By.name( "appointment" ) ).click();

        final Select role = new Select( driver.findElement( By.id( "status" ) ) );
        role.selectByVisibleText( "APPROVED" );

        driver.findElement( By.name( "submit" ) ).click();
    }

    @Then ( "The Ophthalmology request is successfully updated" )
    public void requestUpdated () {
        assertTrue( driver.getPageSource().contains( "Appointment request was successfully updated" ) );
    }

    @And ( "The appointment is in my list of upcoming events" )
    public void upcomingEvents () {
        final SimpleDateFormat sdf = new SimpleDateFormat( "MM/dd/yyyy", Locale.ENGLISH );
        final Long value = Calendar.getInstance().getTimeInMillis()
                + 1000 * 60 * 60 * 24 * 14; /* Two weeks */
        final Calendar future = Calendar.getInstance();
        future.setTimeInMillis( value );
        final String dateString = sdf.format( future.getTime() );
        assertTrue( driver.getPageSource().contains( dateString ) );
        assertTrue( driver.getPageSource().contains( "patient" ) );
    }

    @When ( "I log in as an Ophthalmology hcp" )
    public void loginOpthalHCP () {
        driver.get( baseUrl );
        final WebElement username = driver.findElement( By.name( "username" ) );
        username.clear();
        username.sendKeys( "opht1" );
        final WebElement password = driver.findElement( By.name( "password" ) );
        password.clear();
        password.sendKeys( "123456" );
        final WebElement submit = driver.findElement( By.className( "btn" ) );
        submit.click();
    }

    @When ( "I navigate to the Ophthalmologist Document Office Visit page" )
    public void requestDocumentPageOph () {
        // ( (JavascriptExecutor) driver ).executeScript(
        // "document.getElementById('requestdocumentvisit').click();" );
        driver.get( "http://localhost:8080/iTrust2/ophthalmologist/documentOfficeVisit.html" );

    }

    @When ( "I fill in values in the Ophthalmology Surgery Office Visit for the sample patient" )
    public void fillFieldsPatient () {

        waitForAngular();
        final WebElement date = driver.findElement( By.name( "date" ) );
        date.clear();
        final SimpleDateFormat sdf = new SimpleDateFormat( "MM/dd/yyyy", Locale.ENGLISH );
        final Long value = Calendar.getInstance().getTimeInMillis()
                + 1000 * 60 * 60 * 24 * 14; /* Two weeks */
        final Calendar future = Calendar.getInstance();
        future.setTimeInMillis( value );
        date.sendKeys( sdf.format( future.getTime() ) );
        final WebElement time = driver.findElement( By.name( "time" ) );
        time.clear();
        time.sendKeys( "11:59 PM" );

        // driver.findElement( By.name( "appointment" ) ).click();

        driver.findElement( By.xpath( "//input[@value='General Hospital']" ) ).click();
        driver.findElement( By.xpath( "//input[@value='AliceThirteen']" ) ).click();
        driver.findElement( By.xpath( "//input[@value='OPHTHALMOLOGY_SURGERY']" ) ).click();

        waitForAngular();
        final WebDriverWait wait = new WebDriverWait( driver, 10 );
        final WebElement element = wait.until( ExpectedConditions.visibilityOfElementLocated(
                By.xpath( "//*[@id=\"SURGEYE_METRICS\"]/div/div/div[2]/div[1]/div/div/div[1]/div[2]/input" ) ) );
        // driver.findElement( By.name( "visualLeft" ) ).sendKeys( "1" );
        element.click();
        element.sendKeys( "1" );

        final WebElement VRight = driver.findElement(
                By.xpath( "//*[@id=\"SURGEYE_METRICS\"]/div/div/div[2]/div[1]/div/div/div[2]/div[2]/input" ) );
        VRight.clear();
        VRight.sendKeys( "2" );

        final WebElement sLeft = driver.findElement(
                By.xpath( "//*[@id=\"SURGEYE_METRICS\"]/div/div/div[2]/div[2]/div/div/div[1]/div[2]/input" ) );
        sLeft.clear();
        sLeft.sendKeys( "1" );

        final WebElement sRight = driver.findElement(
                By.xpath( "//*[@id=\"SURGEYE_METRICS\"]/div/div/div[2]/div[2]/div/div/div[2]/div[2]/input" ) );
        sRight.clear();
        sRight.sendKeys( "2" );

        final WebElement submit = driver.findElement( By.name( "submit" ) );
        submit.click();

    }

    @Then ( "The Ophthalmology Surgery Office Visit request is successfully updated" )
    public void requestedSuccessfullyApt () {
        waitForAngular();
        assertTrue( driver.getPageSource().contains( "Office visit created successfully" ) );
        waitForAngular();
    }

    @And ( "The Surgery appointment is in my list of upcoming events" )
    public void findAppointmentSurgery () {
        waitForAngular();
        ( (JavascriptExecutor) driver ).executeScript( "document.getElementById('requestappointment').click();" );

        final SimpleDateFormat sdf = new SimpleDateFormat( "yyyy", Locale.ENGLISH );
        final Long value = Calendar.getInstance().getTimeInMillis()
                + 1000 * 60 * 60 * 24 * 14; /* Two weeks */
        final Calendar future = Calendar.getInstance();
        future.setTimeInMillis( value );
        final String dateString = sdf.format( future.getTime() );
        waitForAngular();

        assertTrue( driver.getPageSource().contains( dateString ) );

    }

}
